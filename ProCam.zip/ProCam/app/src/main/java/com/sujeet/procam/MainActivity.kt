package com.sujeet.procam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.ExifInterface
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

class GridView(ctx: Context) : View(ctx) {
    private val p = Paint().apply { color = 0x88FFFFFF.toInt(); strokeWidth = 2f }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawLine(w / 3, 0f, w / 3, h, p); c.drawLine(2 * w / 3, 0f, 2 * w / 3, h, p)
        c.drawLine(0f, h / 3, w, h / 3, p); c.drawLine(0f, 2 * h / 3, w, 2 * h / 3, p)
    }
}

class MainActivity : ComponentActivity() {

    enum class Mode(val label: String, val frames: Int) {
        PHOTO("Photo", 4), HDR("HDR+", 6), NIGHT("Night", 10), VIDEO("Video", 0)
    }

    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var shutter: TextView
    private lateinit var grid: GridView
    private lateinit var flashBtn: TextView
    private lateinit var timerBtn: TextView
    private val modeViews = ArrayList<TextView>()

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lens = CameraSelector.DEFAULT_BACK_CAMERA
    private var mode = Mode.HDR
    private var flashOn = false
    private var timerSec = 0
    private var busy = false
    private var scaled = false
    private var look = Look.NATURAL
    private lateinit var lookBar: HorizontalScrollView
    private val lookViews = ArrayList<TextView>()
    private var gyro = 0f
    private lateinit var hint: TextView
    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            gyro = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        }
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }
    private val darkLoop = object : Runnable {
        override fun run() { checkDark(); ui.postDelayed(this, 2000) }
    }

    private val exec = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.CAMERA] == true) startCamera() else toast("Camera permission chahiye")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }
    private fun circle(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }

    private fun label(t: String, size: Float = 15f) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER; implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        grid = GridView(this).apply { visibility = View.GONE }
        root.addView(grid, FrameLayout.LayoutParams(-1, -1))

        // zoom (pinch) + tap focus
        val sgd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val c = camera ?: return true
                val z = c.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                c.cameraControl.setZoomRatio(z * d.scaleFactor)
                scaled = true
                return true
            }
        })
        previewView.setOnTouchListener { v, e ->
            sgd.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_DOWN) scaled = false
            if (e.action == MotionEvent.ACTION_UP && !scaled) {
                val pt = previewView.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                v.performClick()
            }
            true
        }

        // top bar
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        flashBtn = label("⚡ off").apply { setOnClickListener { flashOn = !flashOn; text = if (flashOn) "⚡ on" else "⚡ off"; camera?.cameraControl?.enableTorch(flashOn && mode == Mode.VIDEO) } }
        timerBtn = label("⏱ off").apply {
            setOnClickListener {
                timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
                text = if (timerSec == 0) "⏱ off" else "⏱ ${timerSec}s"
            }
        }
        val gridBtn = label("▦ grid").apply { setOnClickListener { grid.visibility = if (grid.visibility == View.GONE) View.VISIBLE else View.GONE } }
        val flipBtn = label("🔄").apply {
            setOnClickListener {
                if (recording != null) return@setOnClickListener
                lens = if (lens == CameraSelector.DEFAULT_BACK_CAMERA) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                bind()
            }
        }
        for (b in listOf(flashBtn, timerBtn, gridBtn, flipBtn)) top.addView(b)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = dp(24) })

        status = label("", 18f)
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(80) })

        hint = label("🌙 Andhera hai, Night mode try karo (tap)", 13f).apply {
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xAA000000.toInt()) }
            visibility = View.GONE
            setOnClickListener { mode = Mode.NIGHT; refreshModes(); bind(); visibility = View.GONE }
        }
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(120) })

        // bottom: modes + shutter
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (m in Mode.values()) {
            val tv = label(m.label, 16f).apply {
                setOnClickListener {
                    if (recording == null && !busy) { mode = m; refreshModes(); bind() }
                }
            }
            modeViews.add(tv); modes.addView(tv)
        }
        shutter = TextView(this).apply {
            background = circle(Color.WHITE)
            setOnClickListener { onShutter() }
        }
        val lookRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        for (lk in Look.values()) {
            val tv = label(lk.label, 13f).apply { setOnClickListener { look = lk; refreshLooks() } }
            lookViews.add(tv); lookRow.addView(tv)
        }
        lookBar = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(lookRow) }
        bottom.addView(lookBar)
        bottom.addView(modes)
        bottom.addView(shutter, LinearLayout.LayoutParams(dp(72), dp(72)).apply { topMargin = dp(12); bottomMargin = dp(32) })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
        refreshModes()

        val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) startCamera()
        else permLauncher.launch(perms.toTypedArray())
    }

    private fun refreshModes() {
        Mode.values().forEachIndexed { i, m -> modeViews[i].setTextColor(if (m == mode) 0xFFFFD600.toInt() else Color.WHITE) }
        lookBar.visibility = if (mode == Mode.VIDEO) View.GONE else View.VISIBLE
        refreshLooks()
    }

    private fun refreshLooks() {
        Look.values().forEachIndexed { i, l -> lookViews[i].setTextColor(if (l == look) 0xFF00E5FF.toInt() else 0xCCFFFFFF.toInt()) }
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({ provider = f.get(); bind() }, ContextCompat.getMainExecutor(this))
    }

    private fun bind() {
        val p = provider ?: return
        try {
            p.unbindAll()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            if (mode == Mode.VIDEO) {
                val rec = Recorder.Builder().setQualitySelector(
                    QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                ).build()
                videoCapture = VideoCapture.withOutput(rec)
                imageCapture = null
                camera = p.bindToLifecycle(this, lens, preview, videoCapture!!)
                camera?.cameraControl?.enableTorch(flashOn)
            } else {
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(if (mode.frames > 1) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .build()
                videoCapture = null
                camera = p.bindToLifecycle(this, lens, preview, imageCapture!!)
            }
        } catch (e: Exception) {
            toast("Camera start fail: ${e.message}")
        }
    }

    private fun onShutter() {
        if (mode == Mode.VIDEO) { toggleVideo(); return }
        if (busy) return
        busy = true
        countdown(timerSec) { capture() }
    }

    private fun countdown(n: Int, done: () -> Unit) {
        if (n <= 0) { status.text = ""; done(); return }
        status.text = "$n"
        ui.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    private fun capture() {
        val ic = imageCapture
        if (ic == null) { busy = false; return }
        val cam = camera
        val total = if (mode == Mode.PHOTO && flashOn) 1 else mode.frames
        val night = mode == Mode.NIGHT
        ic.flashMode = if (total == 1 && flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF

        // exposure plan: Night = max EV sab frames; HDR+ = 0, dark, bright, 0, 0, 0
        val plan = IntArray(total)
        val bracket = BooleanArray(total)
        var evOn = false
        if (cam != null && cam.cameraInfo.exposureState.isExposureCompensationSupported) {
            val st = cam.cameraInfo.exposureState
            val lo = st.exposureCompensationRange.lower
            val up = st.exposureCompensationRange.upper
            if (night) {
                evOn = true
                for (k in 0 until total) plan[k] = up
            } else if (mode == Mode.HDR && total >= 3) {
                val step = st.exposureCompensationStep.toFloat()
                if (step > 0f) {
                    val dark = (-2f / step).roundToInt().coerceIn(lo, up)
                    val bright = (2f / step).roundToInt().coerceIn(lo, up)
                    if (dark < 0 && bright > 0) {
                        evOn = true
                        plan[1] = dark; plan[2] = bright
                        bracket[1] = true; bracket[2] = true
                    }
                }
            }
        }
        val files = ArrayList<File>()

        fun shoot(i: Int) {
            status.text = if (total > 1) "\uD83D\uDCF7 ${i + 1}/$total" else ""
            val change = evOn && ((i == 0 && plan[0] != 0) || (i > 0 && plan[i] != plan[i - 1]))
            if (change) cam!!.cameraControl.setExposureCompensationIndex(plan[i])
            val wait = if (change) (if (i == 0) 900L else 650L) else 0L
            ui.postDelayed({
                waitSteady {
                    val f = File(cacheDir, "f$i.jpg")
                    ic.takePicture(ImageCapture.OutputFileOptions.Builder(f).build(), ContextCompat.getMainExecutor(this),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                                files.add(f)
                                if (i + 1 < total) shoot(i + 1)
                                else {
                                    if (evOn) cam!!.cameraControl.setExposureCompensationIndex(0)
                                    finishPhoto(files, night, look, bracket)
                                }
                            }
                            override fun onError(e: ImageCaptureException) {
                                if (evOn) cam!!.cameraControl.setExposureCompensationIndex(0)
                                toast("Capture fail: ${e.message}"); status.text = ""; busy = false
                            }
                        })
                }
            }, wait)
        }
        shoot(0)
    }

    // phone steady hone tak ruko (gyro), max 1.5 sec
    private fun waitSteady(done: () -> Unit) {
        val start = SystemClock.uptimeMillis()
        var calm = 0
        fun poll() {
            if (gyro < 0.12f) calm++ else calm = 0
            if (calm >= 2 || SystemClock.uptimeMillis() - start > 1500) done()
            else ui.postDelayed({ poll() }, 50)
        }
        poll()
    }

    private fun checkDark() {
        if (busy || recording != null || mode == Mode.VIDEO || mode == Mode.NIGHT) { hint.visibility = View.GONE; return }
        val bmp = previewView.bitmap ?: return
        var sum = 0L
        var cnt = 0
        val sx = max(1, bmp.width / 16)
        val sy = max(1, bmp.height / 16)
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                val c = bmp.getPixel(x, y)
                sum += ((((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10).toLong()
                cnt++
                x += sx
            }
            y += sy
        }
        bmp.recycle()
        hint.visibility = if (cnt > 0 && sum / cnt < 45) View.VISIBLE else View.GONE
    }

    private fun finishPhoto(files: List<File>, night: Boolean, lk: Look, bracket: BooleanArray) {
        val process = files.size > 1 || lk != Look.ORIGINAL
        status.text = if (process) "⏳ Processing... (thoda time lagega)" else ""
        exec.execute {
            var ok = false
            try {
                val merged = File(cacheDir, "merged.jpg")
                var src = files[0]
                if (process) {
                    try {
                        if (Merger.merge(files, night, lk, bracket, merged)) {
                            val o = ExifInterface(files[0].path).getAttribute(ExifInterface.TAG_ORIENTATION)
                            val eo = ExifInterface(merged.path)
                            eo.setAttribute(ExifInterface.TAG_ORIENTATION, o ?: "1")
                            eo.saveAttributes()
                            src = merged
                        }
                    } catch (t: Throwable) { src = files[0] } // OOM etc: single frame save
                }
                ok = savePhoto(src)
                merged.delete()
            } catch (t: Throwable) { ok = false }
            files.forEach { it.delete() }
            ui.post { status.text = ""; busy = false }
            toast(if (ok) "Saved ✔  Pictures/ProCam" else "Save fail")
        }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun savePhoto(src: File): Boolean {
        val name = "IMG_${stamp()}.jpg"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/ProCam")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
            contentResolver.openOutputStream(uri)?.use { o -> src.inputStream().use { it.copyTo(o) } }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ProCam")
            dir.mkdirs()
            val dst = File(dir, name)
            src.copyTo(dst, true)
            MediaScannerConnection.scanFile(this, arrayOf(dst.path), null, null)
        }
        return true
    }

    @SuppressLint("MissingPermission")
    private fun toggleVideo() {
        val vc = videoCapture ?: return
        val r = recording
        if (r != null) { r.stop(); recording = null; return }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/ProCam")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pr = pr.withAudioEnabled()
        }
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            if (ev is VideoRecordEvent.Start) {
                shutter.background = circle(Color.RED); status.text = "● REC"
            } else if (ev is VideoRecordEvent.Finalize) {
                shutter.background = circle(Color.WHITE); status.text = ""; recording = null
                toast(if (ev.hasError()) "Video error" else "Video saved ✔  Movies/ProCam")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { sm.registerListener(sensorListener, it, SensorManager.SENSOR_DELAY_GAME) }
        ui.postDelayed(darkLoop, 2000)
    }

    override fun onPause() {
        (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(sensorListener)
        ui.removeCallbacks(darkLoop)
        super.onPause()
    }

    override fun onDestroy() {
        recording?.stop()
        exec.shutdown()
        super.onDestroy()
    }
}
