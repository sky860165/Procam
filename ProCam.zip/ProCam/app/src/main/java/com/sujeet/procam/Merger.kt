package com.sujeet.procam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * ProCam merge engine v2:
 *  - sharpest normal-exposure frame = reference, blurry frames auto-reject
 *  - global + TILE-based alignment (haath hilne / chhoti motion ke liye)
 *  - linear-light merge, HDR bracket frames (dark/bright) ke saath highlight/shadow recovery
 *  - ghost rejection, vignette correction, local tone mapping
 *  - look styling, chroma denoise, detail sharpen
 * Strips me chalta hai (kam RAM).
 */
object Merger {
    private const val TS = 64 // tile size at 1/2 scale (=128 px full-res)

    private class Gray(val w: Int, val h: Int, val d: IntArray)
    private class Tiles(val nx: Int, val ny: Int, val ox: FloatArray, val oy: FloatArray)

    private val LIN = FloatArray(256) { v ->
        val c = v / 255f
        if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
    }
    private val ENC = FloatArray(4097) { i ->
        val l = i / 4096f
        (if (l <= 0.0031308f) l * 12.92f else 1.055f * l.pow(1f / 2.4f) - 0.055f) * 255f
    }
    private val W_FLAT = FloatArray(256) { v -> if (v >= 250) 0.03f else 1f }
    private val W_BR = FloatArray(256) { v ->
        val x = v / 255f - 0.5f
        max(0.03f, exp(-(x * x) / 0.08f))
    }

    private fun enc(l: Float): Float {
        val i = if (l <= 0f) 0 else if (l >= 1f) 4096 else (l * 4096f).toInt()
        return ENC[i]
    }

    private fun normLut(g: Float) = IntArray(256) { v -> enc(min(1f, LIN[v] * g)).toInt().coerceIn(0, 255) }

    private fun loadGray(path: String, sample: Int, rect: Rect?, lut: IntArray?): Gray? {
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap? = null
        if (rect == null) {
            bmp = BitmapFactory.decodeFile(path, o)
        } else {
            val dec = BitmapRegionDecoder.newInstance(path, false)
            try { bmp = dec.decodeRegion(rect, o) } finally { dec.recycle() }
        }
        if (bmp == null) return null
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()
        for (i in px.indices) {
            val c = px[i]
            val gv = (((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10
            px[i] = if (lut != null) lut[gv] else gv
        }
        return Gray(w, h, px)
    }

    // exposure ratio: lin_ref ~ gain * lin_cur
    private fun gainOf(ref: Gray, cur: Gray): Float {
        var sr = 0.0
        var sc = 0.0
        for (k in ref.d.indices) {
            val a = ref.d[k]
            val b = cur.d[k]
            if (a in 30..225 && b in 30..225) { sr += LIN[a]; sc += LIN[b] }
        }
        if (sr <= 0.0 || sc <= 0.0) return 1f
        return (sr / sc).toFloat().coerceIn(0.2f, 5f)
    }

    // cur(x+dx, y+dy) ~ ref(x, y) (SAD search)
    private fun shift(ref: Gray, cur: Gray, r: Int, step: Int): IntArray {
        var best = Long.MAX_VALUE
        var bx = 0
        var by = 0
        val w = ref.w
        val h = ref.h
        for (dy in -r..r) {
            for (dx in -r..r) {
                var s = 0L
                var y = r
                while (y < h - r) {
                    val ro = y * w
                    val co = (y + dy) * w + dx
                    var x = r
                    while (x < w - r) {
                        s += abs(ref.d[ro + x] - cur.d[co + x])
                        x += step
                    }
                    y += step
                }
                if (s < best) { best = s; bx = dx; by = dy }
            }
        }
        return intArrayOf(bx, by)
    }

    // tile-wise local alignment at 1/2 scale around the global offset (gx, gy in half-scale px)
    private fun tileAlign(a: Gray, b: Gray, gx: Int, gy: Int, nx: Int, ny: Int): Tiles {
        val ox = FloatArray(nx * ny)
        val oy = FloatArray(nx * ny)
        val r = 3
        for (ty in 0 until ny) {
            for (tx in 0 until nx) {
                val x0 = tx * TS
                val y0 = ty * TS
                var best = Long.MAX_VALUE
                var bx = 0
                var by = 0
                for (dy in -r..r) {
                    for (dx in -r..r) {
                        val sx0 = x0 + gx + dx
                        val sy0 = y0 + gy + dy
                        if (sx0 < 0 || sy0 < 0 || sx0 + TS > b.w || sy0 + TS > b.h) continue
                        var s = 0L
                        var yy = 0
                        while (yy < TS) {
                            val ro = (y0 + yy) * a.w + x0
                            val co = (sy0 + yy) * b.w + sx0
                            var xx = 0
                            while (xx < TS) {
                                s += abs(a.d[ro + xx] - b.d[co + xx])
                                xx += 2
                            }
                            yy += 2
                        }
                        s += (abs(dx) + abs(dy)) * 24L // textureless tile = global offset par rahe
                        if (s < best) { best = s; bx = dx; by = dy }
                    }
                }
                ox[ty * nx + tx] = ((gx + bx) * 2).toFloat()
                oy[ty * nx + tx] = ((gy + by) * 2).toFloat()
            }
        }
        return Tiles(nx, ny, ox, oy)
    }

    private fun blurLow(g: Gray, r: Int): FloatArray {
        val w = g.w
        val h = g.h
        val tmp = FloatArray(w * h)
        val o = FloatArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                var c = 0
                for (k in -r..r) {
                    val xx = x + k
                    if (xx in 0 until w) { s += g.d[y * w + xx]; c++ }
                }
                tmp[y * w + x] = s / c
            }
        }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                var c = 0
                for (k in -r..r) {
                    val yy = y + k
                    if (yy in 0 until h) { s += tmp[yy * w + x]; c++ }
                }
                o[y * w + x] = s / c
            }
        }
        return o
    }

    fun merge(files: List<File>, night: Boolean, look: Look, bracket: BooleanArray, out: File): Boolean {
        val n = files.size
        val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(files[0].path, bo)
        val W = bo.outWidth
        val H = bo.outHeight
        if (W < 1100 || H < 1100 || bracket.size != n) return false

        // 1) coarse gray (1/8), sharpness, reference (normal exposure me sabse sharp)
        val cg = ArrayList<Gray>()
        for (f in files) cg.add(loadGray(f.path, 8, null, null) ?: return false)
        val gw = cg[0].w
        val gh = cg[0].h
        for (g in cg) if (g.w != gw || g.h != gh) return false

        val sharp = LongArray(n)
        for (i in 0 until n) {
            val g = cg[i]
            var s = 0L
            for (y in 0 until g.h) {
                val o = y * g.w
                for (x in 1 until g.w) s += abs(g.d[o + x] - g.d[o + x - 1])
            }
            sharp[i] = s
        }
        var ri = -1
        for (i in 0 until n) if (!bracket[i] && (ri < 0 || sharp[i] > sharp[ri])) ri = i
        if (ri < 0) ri = 0

        // 2) exposure gains, normalisation LUTs, blurry-frame rejection
        val gains = FloatArray(n) { 1f }
        val norm = arrayOfNulls<IntArray>(n)
        val keep = BooleanArray(n) { true }
        var rmax = 1f
        for (i in 0 until n) {
            if (i == ri) continue
            gains[i] = gainOf(cg[ri], cg[i])
            norm[i] = normLut(gains[i])
            if (bracket[i]) {
                if (gains[i] > rmax) rmax = gains[i]
            } else if (sharp[i] < sharp[ri] * 0.6) {
                keep[i] = false
            }
        }

        // 3) alignment: global (coarse + refine) then tile-wise
        val refHalf = loadGray(files[ri].path, 2, null, null) ?: return false
        val nxT = max(1, refHalf.w / TS)
        val nyT = max(1, refHalf.h / TS)
        val tiles = arrayOfNulls<Tiles>(n)
        val minOY = IntArray(n)
        val maxOY = IntArray(n)
        for (i in 0 until n) {
            if (i == ri || !keep[i]) continue
            val lut = norm[i]!!
            val curC = Gray(cg[i].w, cg[i].h, IntArray(cg[i].d.size) { lut[cg[i].d[it]] })
            val s = shift(cg[ri], curC, 8, 2)
            var ox = s[0] * 8
            var oy = s[1] * 8
            val half = 512
            val left = (W - 2 * half) / 2
            val top = (H - 2 * half) / 2
            val rRect = Rect(left, top, left + 2 * half, top + 2 * half)
            val cRect = Rect(left + ox, top + oy, left + ox + 2 * half, top + oy + 2 * half)
            if (cRect.left >= 0 && cRect.top >= 0 && cRect.right <= W && cRect.bottom <= H) {
                val a = loadGray(files[ri].path, 2, rRect, null)
                val b = loadGray(files[i].path, 2, cRect, lut)
                if (a != null && b != null && a.w == b.w && a.h == b.h) {
                    val r = shift(a, b, 5, 2)
                    ox += r[0] * 2
                    oy += r[1] * 2
                }
            }
            val curH = loadGray(files[i].path, 2, null, lut)
            val t = if (curH != null && curH.w == refHalf.w && curH.h == refHalf.h) {
                tileAlign(refHalf, curH, ox / 2, oy / 2, nxT, nyT)
            } else {
                Tiles(nxT, nyT, FloatArray(nxT * nyT) { ox.toFloat() }, FloatArray(nxT * nyT) { oy.toFloat() })
            }
            var mn = t.oy[0]
            var mx = t.oy[0]
            for (v in t.oy) { if (v < mn) mn = v; if (v > mx) mx = v }
            minOY[i] = mn.toInt() - 2
            maxOY[i] = mx.toInt() + 2
            tiles[i] = t
        }

        // 4) precomputed lookups
        val colT0 = IntArray(W)
        val colT1 = IntArray(W)
        val colTw = FloatArray(W)
        val colG0 = IntArray(W)
        val colG1 = IntArray(W)
        val colGw = FloatArray(W)
        val dx2 = FloatArray(W)
        for (x in 0 until W) {
            val f = (x / (2f * TS) - 0.5f).coerceIn(0f, (nxT - 1).toFloat())
            val t0 = f.toInt()
            colT0[x] = t0; colT1[x] = min(nxT - 1, t0 + 1); colTw[x] = f - t0
            val gf = ((x + 0.5f) / 8f - 0.5f).coerceIn(0f, (gw - 1).toFloat())
            val g0 = gf.toInt()
            colG0[x] = g0; colG1[x] = min(gw - 1, g0 + 1); colGw[x] = gf - g0
            val d = (x - W / 2f) / (W / 2f)
            dx2[x] = d * d
        }
        val low = blurLow(cg[ri], 6)
        val ltK = if (night) 0.35 else if (rmax > 1.05f) 0.30 else 0.20
        val ltLut = FloatArray(256) { v -> ((0.45 / (v / 255.0 + 0.04)).pow(ltK)).coerceIn(0.85, 1.9).toFloat() }

        val gamma = look.gamma * (if (night) 0.72 else 1.0)
        val lut = IntArray(256) { v ->
            var y = (v / 255.0).pow(gamma)
            val s = y * y * (3 - 2 * y)
            y += look.contrast * (s - y)
            y = look.fade + y * (1 - look.fade)
            (y * 255 + 0.5).toInt().coerceIn(0, 255)
        }
        val rGain = 1f + 0.10f * look.warm
        val bGain = 1f - 0.10f * look.warm
        val t1 = if (night) 24 else 14
        val t2 = if (night) 70 else 40
        val inv = 1f / (t2 - t1)
        val knee = 0.6f
        val sS = (rmax - knee) / 2.5f
        val cn = if (night) 0.8f else if (n > 1) 0.5f else 0.3f
        val amt = look.sharp

        // 5) strip-wise merge + styling
        val decs = ArrayList<BitmapRegionDecoder>()
        try {
            for (f in files) decs.add(BitmapRegionDecoder.newInstance(f.path, false))
            val outBmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            val strip = 256
            val ov = 1
            val maxNp = W * (strip + 2 * ov)
            val refPx = IntArray(maxNp)
            val refL = IntArray(maxNp)
            val aR = FloatArray(maxNp)
            val aG = FloatArray(maxNp)
            val aB = FloatArray(maxNp)
            val wS = FloatArray(maxNp)
            val op = IntArray(maxNp)
            val lum = IntArray(maxNp)
            val dR = IntArray(maxNp)
            val dG = IntArray(maxNp)
            val dB = IntArray(maxNp)
            val res = IntArray(W * strip)
            val vx = FloatArray(nxT)
            val vy = FloatArray(nxT)
            var pxBuf = IntArray(0)

            var y0 = 0
            while (y0 < H) {
                val y1 = min(H, y0 + strip)
                val ys = max(0, y0 - ov)
                val ye = min(H, y1 + ov)
                val sh = ye - ys
                val np = W * sh

                val rb = decs[ri].decodeRegion(Rect(0, ys, W, ye), null)
                rb.getPixels(refPx, 0, W, 0, 0, W, sh)
                rb.recycle()
                for (p in 0 until np) {
                    val c = refPx[p]
                    val r = (c shr 16) and 255
                    val g = (c shr 8) and 255
                    val b = c and 255
                    val l = (r * 3 + g * 6 + b) / 10
                    refL[p] = l
                    val w0 = W_FLAT[l]
                    aR[p] = LIN[r] * w0; aG[p] = LIN[g] * w0; aB[p] = LIN[b] * w0; wS[p] = w0
                }

                for (i in 0 until n) {
                    if (i == ri || !keep[i]) continue
                    val t = tiles[i] ?: continue
                    val tt = max(0, ys + minOY[i])
                    val bb = min(H, ye + maxOY[i])
                    if (bb - tt < 1) continue
                    val cb = decs[i].decodeRegion(Rect(0, tt, W, bb), null)
                    val ch = cb.height
                    if (pxBuf.size < W * ch) pxBuf = IntArray(W * ch)
                    cb.getPixels(pxBuf, 0, W, 0, 0, W, ch)
                    cb.recycle()
                    val wTab = if (bracket[i]) W_BR else W_FLAT
                    val nl = norm[i]!!
                    val gk = gains[i]
                    for (yy in 0 until sh) {
                        val y = ys + yy
                        val fy = (y / (2f * TS) - 0.5f).coerceIn(0f, (t.ny - 1).toFloat())
                        val ty0 = fy.toInt()
                        val ty1 = min(t.ny - 1, ty0 + 1)
                        val wy = fy - ty0
                        for (k in 0 until nxT) {
                            vx[k] = t.ox[ty0 * t.nx + k] * (1f - wy) + t.ox[ty1 * t.nx + k] * wy
                            vy[k] = t.oy[ty0 * t.nx + k] * (1f - wy) + t.oy[ty1 * t.nx + k] * wy
                        }
                        val po = yy * W
                        for (x in 0 until W) {
                            val a0 = colT0[x]
                            val a1 = colT1[x]
                            val aw = colTw[x]
                            val ox = vx[a0] + (vx[a1] - vx[a0]) * aw
                            val oy = vy[a0] + (vy[a1] - vy[a0]) * aw
                            val sx = ((x + ox + 1024.5f).toInt() - 1024).coerceIn(0, W - 1)
                            val sy = ((y + oy + 1024.5f).toInt() - 1024).coerceIn(tt, bb - 1) - tt
                            val c = pxBuf[sy * W + sx]
                            val r = (c shr 16) and 255
                            val g = (c shr 8) and 255
                            val b = c and 255
                            val lc = (r * 3 + g * 6 + b) / 10
                            val lr = refL[po + x]
                            var w = wTab[lc]
                            if (lr in 8..245 && lc in 8..245) {
                                val d = abs(nl[lc] - lr)
                                if (d >= t2) continue
                                if (d > t1) w *= (t2 - d) * inv
                            }
                            val p = po + x
                            aR[p] += LIN[r] * gk * w
                            aG[p] += LIN[g] * gk * w
                            aB[p] += LIN[b] * gk * w
                            wS[p] += w
                        }
                    }
                }

                // radiance -> tone map -> vignette -> local tone -> look
                for (yy in 0 until sh) {
                    val y = ys + yy
                    val gf = ((y + 0.5f) / 8f - 0.5f).coerceIn(0f, (gh - 1).toFloat())
                    val gy0 = gf.toInt()
                    val gy1 = min(gh - 1, gy0 + 1)
                    val gwy = gf - gy0
                    val dyv = (y - H / 2f) / (H / 2f)
                    val dy2 = dyv * dyv
                    for (x in 0 until W) {
                        val p = yy * W + x
                        val iw = 1f / wS[p]
                        var lr = aR[p] * iw
                        var lg = aG[p] * iw
                        var lb = aB[p] * iw
                        if (rmax > 1.15f) {
                            val l0 = lr * 0.3f + lg * 0.59f + lb * 0.11f
                            if (l0 > knee) {
                                val mapped = knee + (1f - knee) * (1f - exp(-(l0 - knee) / sS))
                                val sc = mapped / l0
                                lr *= sc; lg *= sc; lb *= sc
                            }
                        }
                        var r = enc(lr)
                        var g = enc(lg)
                        var b = enc(lb)

                        val vg = 1f + 0.12f * (dx2[x] + dy2)
                        r *= vg; g *= vg; b *= vg

                        val ga = colG0[x]
                        val gb = colG1[x]
                        val gww = colGw[x]
                        val tp = low[gy0 * gw + ga] * (1f - gww) + low[gy0 * gw + gb] * gww
                        val bt = low[gy1 * gw + ga] * (1f - gww) + low[gy1 * gw + gb] * gww
                        val lowv = tp + (bt - tp) * gwy
                        val lgn = ltLut[lowv.toInt().coerceIn(0, 255)]
                        val hl = (r * 0.299f + g * 0.587f + b * 0.114f) / 255f
                        val f2 = 1f + (lgn - 1f) * (1f - min(1f, hl * hl))
                        r *= f2; g *= f2; b *= f2

                        r *= rGain; b *= bGain
                        val l = r * 0.299f + g * 0.587f + b * 0.114f
                        if (look.teal != 0f) {
                            val ln = l / 255f
                            val sw = (1f - ln) * look.teal
                            val hw = ln * look.teal
                            r += -10f * sw + 14f * hw
                            g += 4f * sw + 4f * hw
                            b += 12f * sw - 12f * hw
                        }
                        if (look.mono) {
                            r = l; g = l; b = l
                        } else if (look.sat != 1f) {
                            val mx = max(r, max(g, b))
                            val mn = min(r, min(g, b))
                            val e0 = 1f + (look.sat - 1f) * (1f - 0.5f * ((mx - mn) / 255f))
                            val skin = r > 95f && g > 40f && b > 20f && r > g && r > b && (r - mn) > 15f && abs(r - g) > 12f
                            val e = if (skin) 1f + (e0 - 1f) * 0.4f else e0
                            r = l + (r - l) * e
                            g = l + (g - l) * e
                            b = l + (b - l) * e
                        }
                        val ro = lut[(r + 0.5f).toInt().coerceIn(0, 255)]
                        val go = lut[(g + 0.5f).toInt().coerceIn(0, 255)]
                        val bo2 = lut[(b + 0.5f).toInt().coerceIn(0, 255)]
                        val lv = (ro * 3 + go * 6 + bo2) / 10
                        op[p] = (0xFF shl 24) or (ro shl 16) or (go shl 8) or bo2
                        lum[p] = lv
                        dR[p] = ro - lv
                        dG[p] = go - lv
                        dB[p] = bo2 - lv
                    }
                }

                // chroma denoise + detail sharpen, sirf inner rows likhte hain
                val inner = y1 - y0
                val base = y0 - ys
                for (yy in 0 until inner) {
                    val r0 = base + yy
                    val ra = if (r0 > 0) r0 - 1 else 0
                    val rbw = if (r0 < sh - 1) r0 + 1 else sh - 1
                    val rowA = ra * W
                    val rowM = r0 * W
                    val rowB = rbw * W
                    for (x in 0 until W) {
                        val idx = rowM + x
                        val xa = if (x > 0) x - 1 else 0
                        val xb = if (x < W - 1) x + 1 else W - 1
                        val i1 = rowA + xa; val i2 = rowA + x; val i3 = rowA + xb
                        val i4 = rowM + xa; val i6 = rowM + xb
                        val i7 = rowB + xa; val i8 = rowB + x; val i9 = rowB + xb
                        val lv = lum[idx]
                        val sL = lum[i1] + lum[i2] + lum[i3] + lum[i4] + lv + lum[i6] + lum[i7] + lum[i8] + lum[i9]
                        var d = lv - sL / 9f
                        d = if (abs(d) < 2f) 0f else d.coerceIn(-40f, 40f)
                        val k = d * amt
                        val mr = (dR[i1] + dR[i2] + dR[i3] + dR[i4] + dR[idx] + dR[i6] + dR[i7] + dR[i8] + dR[i9]) / 9f
                        val mg = (dG[i1] + dG[i2] + dG[i3] + dG[i4] + dG[idx] + dG[i6] + dG[i7] + dG[i8] + dG[i9]) / 9f
                        val mb = (dB[i1] + dB[i2] + dB[i3] + dB[i4] + dB[idx] + dB[i6] + dB[i7] + dB[i8] + dB[i9]) / 9f
                        val rr = (lv + dR[idx] + cn * (mr - dR[idx]) + k + 0.5f).toInt().coerceIn(0, 255)
                        val gg = (lv + dG[idx] + cn * (mg - dG[idx]) + k + 0.5f).toInt().coerceIn(0, 255)
                        val bl = (lv + dB[idx] + cn * (mb - dB[idx]) + k + 0.5f).toInt().coerceIn(0, 255)
                        res[yy * W + x] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bl
                    }
                }
                outBmp.setPixels(res, 0, W, 0, y0, W, inner)
                y0 = y1
            }
            FileOutputStream(out).use { outBmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            outBmp.recycle()
            return true
        } finally {
            for (d in decs) d.recycle()
        }
    }
}
