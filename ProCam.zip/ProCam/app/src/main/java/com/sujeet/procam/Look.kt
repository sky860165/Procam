package com.sujeet.procam

/** Photo look presets. gamma<1 = brighter shadows, contrast = S-curve, sat = vibrance,
 *  warm +/-1 = warm/cool, fade = lifted blacks, sharp = detail, teal = cinematic split-tone */
enum class Look(
    val label: String,
    val gamma: Double,
    val contrast: Double,
    val sat: Float,
    val warm: Float,
    val fade: Double,
    val mono: Boolean,
    val sharp: Float,
    val teal: Float
) {
    ORIGINAL("Original", 1.0, 0.0, 1f, 0f, 0.0, false, 0f, 0f),
    NATURAL("Natural", 0.92, 0.10, 1.05f, 0f, 0.0, false, 0.5f, 0f),
    VIVID("Vivid", 0.92, 0.20, 1.35f, 0f, 0.0, false, 0.6f, 0f),
    EYE("Eye-catching", 0.88, 0.35, 1.55f, 0.15f, 0.0, false, 0.9f, 0f),
    CINEMATIC("Cinematic", 0.95, 0.25, 0.90f, 0f, 0.04, false, 0.5f, 1f),
    WARM("Warm", 0.92, 0.12, 1.15f, 0.8f, 0.0, false, 0.5f, 0f),
    COOL("Cool", 0.92, 0.12, 1.10f, -0.8f, 0.0, false, 0.5f, 0f),
    BW("B&W", 0.95, 0.40, 1f, 0f, 0.0, true, 0.8f, 0f),
    FILM("Film", 1.0, 0.05, 0.85f, 0.25f, 0.08, false, 0.2f, 0.4f),
    HDRPOP("HDR Pop", 0.78, 0.30, 1.25f, 0f, 0.0, false, 1.1f, 0f),
    SOFT("Soft Glow", 0.85, 0.02, 1.0f, 0.3f, 0.0, false, 0f, 0f),
    FOOD("Food", 0.88, 0.22, 1.40f, 0.4f, 0.0, false, 0.7f, 0f)
}
